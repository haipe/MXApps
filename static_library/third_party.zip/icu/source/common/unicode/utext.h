#ifndef utext_h
#define utext_h

extern "C" {

struct UText;
typedef struct UText UText; /**< C typedef for struct UText. @stable ICU 3.6 */

} // extern "C"

#endif // utext_h