#ifndef BRKITER_H
#define BRKITER_H

#include "unicode/utypes.h"
#include "unicode/utext.h"

namespace icu {

class  BreakIterator;

} // namespace icu

#endif // BRKITER_H